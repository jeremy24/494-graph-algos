## HW 5 ##

### Usage ###
To Run:   python go.py [graph file]
