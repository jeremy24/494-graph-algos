## HW 4 ##

### Usage ###
To Run:   python go.py [graph file]
