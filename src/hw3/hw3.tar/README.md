## HW 3 - Jeremy Poff ##

2. python go.py [graph] [start] [end]
